<?php return array (
  'question' => 'App\\Http\\Livewire\\Question',
  'register' => 'App\\Http\\Livewire\\Register',
);